sap.ui.define([
	"simplot/portalsprd/utils/models"
], function(models){
	return models.start;
});