
sap.ui.define(['sap/uxap/BlockBase'],
	function (BlockBase) {
		"use strict";
		var BlockPhoneNumber = BlockBase.extend("simplot.portalsprd.view.Autogestion.SectionBlocks.personal.BlockPhoneNumber", {
			metadata: {}
		});
		return BlockPhoneNumber;
	});
