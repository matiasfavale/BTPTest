sap.ui.define(['sap/uxap/BlockBase'], function (BlockBase) {
	"use strict";

	var BlockMailing = BlockBase.extend("simplot.portalsprd.view.Autogestion.SectionBlocks.personal.BlockMailing", {
		metadata: {}
	});

	return BlockMailing;
}, true);
