sap.ui.define(["sap/uxap/BlockBase"], function (BlockBase) {
	"use strict";

	var BlockAdresses = BlockBase.extend("simplot.portalsprd.view.Autogestion.SectionBlocks.personal.BlockAdresses", {
		metadata: {}
	});
	return BlockAdresses;
}, true);
