sap.ui.define(['sap/uxap/BlockBase'], function (BlockBase) {
	"use strict";

	var BlockMailing = BlockBase.extend("simplot.portalsqas.view.Autogestion.SectionBlocks.personal.BlockMailing", {
		metadata: {}
	});

	return BlockMailing;
}, true);
