sap.ui.define(['sap/uxap/BlockBase'], function (BlockBase) {
	"use strict";

	var BlockSocial = BlockBase.extend("simplot.portalsqas.view.Autogestion.SectionBlocks.personal.BlockSocial", {
		metadata: {}
	});
	return BlockSocial;

});
