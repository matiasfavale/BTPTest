sap.ui.define([
	"simplot/portalsqas/utils/models"
], function(models){
	return models.start;
});